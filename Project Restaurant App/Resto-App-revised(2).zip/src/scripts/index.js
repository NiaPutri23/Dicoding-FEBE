import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import main from './main.js';
import data from '../public/data/DATA.json';


console.log('Hello Coders! :)');
main();