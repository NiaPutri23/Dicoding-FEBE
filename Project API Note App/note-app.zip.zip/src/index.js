import 'regenerator-runtime/runtime'
import './styles/main.css'
import main from './scripts/main'

main()
